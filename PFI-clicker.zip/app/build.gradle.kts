plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pfigroup.clicker"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pfigroup.clicker"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }
    signingConfigs {
        create("pfi") {
            storeFile = file("pfi.keystore")
            storePassword = "pfi123456"
            keyAlias = "pfi"
            keyPassword = "pfi123456"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("pfi") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("pfi")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
