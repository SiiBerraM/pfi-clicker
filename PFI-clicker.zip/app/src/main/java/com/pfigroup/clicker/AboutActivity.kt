package com.pfigroup.clicker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class AboutActivity : Activity() {

    private val gold = Color.parseColor("#D4AF37")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false, top: Int = 8) =
        TextView(this).apply {
            this.text = t
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(top), 0, 0)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(22), dp(22), dp(18))
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(80), dp(80))
        })
        root.addView(text("عنا", 22f, gold, true, 10))
        root.addView(text(
            "نحن P.F.I Group، فريق عربي يصنع أدوات وتطبيقات بسيطة تسهّل عليكم حياتكم اليومية.",
            15f, Color.WHITE, false, 12
        ))
        root.addView(text(
            "شكراً لكم من القلب على استخدام P.F.I clicker، فثقتكم ودعمكم هما ما يدفعنا للاستمرار والتطوير.",
            15f, Color.WHITE, false, 12
        ))
        root.addView(text("— القائد Berra", 16f, gold, true, 16))
        root.addView(text("Produced by Berratone", 11f, Color.LTGRAY, false, 10))

        root.addView(Button(this).apply {
            text = "إغلاق"
            setTextColor(Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { setColor(gold); cornerRadius = dp(14).toFloat() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(46)
            ).apply { topMargin = dp(16) }
            setOnClickListener { finish() }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
