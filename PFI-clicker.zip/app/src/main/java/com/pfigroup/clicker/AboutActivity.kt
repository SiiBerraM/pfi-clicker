package com.pfigroup.clicker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class AboutActivity : Activity() {

    private val gold = Color.parseColor("#D4AF37")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false, top: Int = 6) =
        TextView(this).apply {
            this.text = t
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(top), 0, 0)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64)).apply { marginEnd = dp(12) }
        })

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        col.addView(text("عنا", 18f, gold, true, 0))
        col.addView(text(
            "نحن P.F.I Group، فريق عربي يصنع أدوات وتطبيقات بسيطة تسهّل عليكم حياتكم اليومية.",
            13f, Color.WHITE, false, 6
        ))
        col.addView(text(
            "شكراً لكم من القلب على استخدام P.F.I clicker، فثقتكم ودعمكم هما ما يدفعنا للاستمرار والتطوير.",
            13f, Color.WHITE, false, 6
        ))
        col.addView(text("— القائد Berra", 14f, gold, true, 10))
        col.addView(text("Produced by Berratone", 10f, Color.LTGRAY, false, 4))
        col.addView(Button(this).apply {
            text = "إغلاق"
            textSize = 12f
            minWidth = 0
            minHeight = 0
            setPadding(dp(16), dp(7), dp(16), dp(7))
            setTextColor(Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { setColor(gold); cornerRadius = dp(12).toFloat() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
            setOnClickListener { finish() }
        })
        root.addView(col)

        setContentView(ScrollView(this).apply { addView(root) })
        window.setLayout(
            minOf((resources.displayMetrics.widthPixels * 0.94).toInt(), dp(480)),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
}
