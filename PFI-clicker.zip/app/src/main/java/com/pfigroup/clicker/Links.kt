package com.pfigroup.clicker

object Links {
    // صفحة شرح حل المشكلة (يمكن تعديل محتواها من GitHub بدون إعادة بناء التطبيق)
    const val VIDEO = "https://github.com/SiiBerraM/pfi-clicker"
}
