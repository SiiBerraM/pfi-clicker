package com.pfigroup.clicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class ClickerService : AccessibilityService() {

    companion object {
        var instance: ClickerService? = null
    }

    private val gold = Color.parseColor("#D4AF37")
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var panel: LinearLayout? = null
    private var playBtn: TextView? = null
    private var settingsCard: LinearLayout? = null
    private val points = mutableListOf<TextView>()
    private val pointParams = mutableMapOf<TextView, LP>()

    private var running = false
    private var idx = 0
    private var clicks = 0
    private var startedAt = 0L
    private var cfg = Cfg(500, 0, 20, 0, 0)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() { stopClicking() }

    override fun onUnbind(intent: Intent?): Boolean {
        hideOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- اللوحة العائمة ----------

    fun showOverlay() {
        if (panel != null) return
        buildPanel()
        addPoint()
    }

    fun hideOverlay() {
        stopClicking()
        points.forEach { runCatching { wm.removeView(it) } }
        points.clear()
        pointParams.clear()
        settingsCard?.let { runCatching { wm.removeView(it) } }
        settingsCard = null
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    private fun overlayParams(w: Int, h: Int) = LP(
        w, h, LP.TYPE_ACCESSIBILITY_OVERLAY,
        LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.LEFT }

    private fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 20f
        setTextColor(gold)
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        setOnClickListener { onClick() }
    }

    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6101820"))
                cornerRadius = dp(28).toFloat()
                setStroke(dp(2), gold)
            }
        }
        val lp = overlayParams(LP.WRAP_CONTENT, LP.WRAP_CONTENT).apply {
            x = dp(8); y = dp(120)
        }

        val handle = btn("⠿") {}
        handle.setOnTouchListener(dragListener(lp, p))
        val play = btn("▶") { toggle() }
        playBtn = play

        p.addView(handle)
        p.addView(play)
        p.addView(btn("＋") { addPoint() })
        p.addView(btn("－") { removePoint() })
        p.addView(btn("⚙") { toggleSettings() })
        p.addView(btn("✕") { hideOverlay() })

        wm.addView(p, lp)
        panel = p
    }

    private fun dragListener(params: LP, view: View): View.OnTouchListener {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    params.x = sx + (e.rawX - tx).toInt()
                    params.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(view, params)
                }
            }
            true
        }
    }

    // ---------- نافذة الإعدادات الصغيرة ----------

    private fun updateCfg(f: (Cfg) -> Cfg) {
        cfg = f(Prefs.load(this))
        Prefs.save(this, cfg)
    }

    private fun mini(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 20f
        setTextColor(gold)
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
        setOnClickListener { onClick() }
    }

    private fun row(
        title: String, lo: Int, hi: Int, step: Int, unit: String, zeroText: String?,
        get: () -> Int, set: (Int) -> Unit
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(2))
        }
        val name = TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val valueTv = TextView(this).apply {
            setTextColor(gold); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(name); addView(valueTv)
        }
        fun fmt(v: Int) = if (v == 0 && zeroText != null) zeroText else "$v $unit"

        val seek = SeekBar(this)
        seek.max = (hi - lo) / step
        seek.progress = ((get() - lo) / step).coerceIn(0, seek.max)
        seek.progressTintList = ColorStateList.valueOf(gold)
        seek.thumbTintList = ColorStateList.valueOf(gold)
        seek.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        valueTv.text = fmt(get())

        fun nudge(d: Int) {
            val p = (seek.progress + d).coerceIn(0, seek.max)
            seek.progress = p
            set(lo + p * step)
            valueTv.text = fmt(lo + p * step)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = lo + p * step
                valueTv.text = fmt(v)
                if (fromUser) set(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(mini("－") { nudge(-1) })
            addView(seek)
            addView(mini("＋") { nudge(1) })
        }
        box.addView(head)
        box.addView(line)
        return box
    }

    private fun openAbout() {
        startActivity(Intent(this, AboutActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun openVideo() {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Links.VIDEO)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun linkBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(gold)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), gold)
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(4); marginEnd = dp(4) }
        setOnClickListener { onClick() }
    }

    private fun toggleSettings() {
        settingsCard?.let {
            runCatching { wm.removeView(it) }
            settingsCard = null
            return
        }
        val c = Prefs.load(this)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), dp(4), dp(4), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2101820"))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(2), gold)
            }
        }
        val lp = overlayParams(dp(300), LP.WRAP_CONTENT).apply { x = dp(8); y = dp(190) }

        val title = TextView(this).apply {
            text = "⠿  الإعدادات"
            setTextColor(gold); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(6))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnTouchListener(dragListener(lp, card))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title)
            addView(mini("✕") { toggleSettings() })
        }
        card.addView(head)
        card.addView(row("الفاصل بين النقرات", 20, 5000, 10, "ms", null,
            { c.intervalMs.toInt() }) { v -> updateCfg { it.copy(intervalMs = v.toLong()) } })
        card.addView(row("عشوائية التوقيت", 0, 90, 5, "%", "ثابت",
            { c.jitterPct }) { v -> updateCfg { it.copy(jitterPct = v) } })
        card.addView(row("مدة الضغطة", 1, 500, 1, "ms", null,
            { c.holdMs.toInt() }) { v -> updateCfg { it.copy(holdMs = v.toLong()) } })
        card.addView(row("إيقاف بعد عدد نقرات", 0, 2000, 10, "", "بلا حد",
            { c.maxClicks }) { v -> updateCfg { it.copy(maxClicks = v) } })
        card.addView(row("إيقاف بعد دقائق", 0, 180, 1, "د", "بلا حد",
            { c.maxMinutes }) { v -> updateCfg { it.copy(maxMinutes = v) } })

        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
            addView(linkBtn("ℹ عنا") { openAbout() })
            addView(linkBtn("▶ شرح المشكلة") { openVideo() })
        })

        wm.addView(card, lp)
        settingsCard = card
    }

    // ---------- نقاط النقر ----------

    private fun addPoint() {
        if (running || points.size >= 20) return
        val size = dp(52)
        val n = points.size + 1
        val dm = resources.displayMetrics
        val tv = TextView(this).apply {
            text = "$n"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#B3D4AF37"))
                setStroke(dp(3), Color.WHITE)
            }
        }
        val lp = overlayParams(size, size).apply {
            x = dm.widthPixels / 2 - size / 2 + (n - 1) * dp(14)
            y = dm.heightPixels / 2 - size / 2 + (n - 1) * dp(14)
        }
        tv.setOnTouchListener(dragListener(lp, tv))
        wm.addView(tv, lp)
        points.add(tv)
        pointParams[tv] = lp
    }

    private fun removePoint() {
        if (running || points.size <= 1) return
        val tv = points.removeAt(points.size - 1)
        pointParams.remove(tv)
        runCatching { wm.removeView(tv) }
    }

    private fun setPointsTouchable(touchable: Boolean) {
        points.forEach { tv ->
            val lp = pointParams[tv] ?: return@forEach
            lp.flags = if (touchable) lp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
            else lp.flags or LP.FLAG_NOT_TOUCHABLE
            tv.alpha = if (touchable) 1f else 0.45f
            runCatching { wm.updateViewLayout(tv, lp) }
        }
    }

    // ---------- التشغيل ----------

    private fun toggle() { if (running) stopClicking() else startClicking() }

    private fun startClicking() {
        if (points.isEmpty()) return
        cfg = Prefs.load(this)
        running = true
        idx = 0
        clicks = 0
        startedAt = System.currentTimeMillis()
        playBtn?.text = "⏸"
        setPointsTouchable(false)
        handler.postDelayed(loop, 400)
    }

    fun stopClicking() {
        if (!running) return
        running = false
        handler.removeCallbacks(loop)
        playBtn?.text = "▶"
        setPointsTouchable(true)
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return

            if (cfg.maxMinutes > 0 &&
                System.currentTimeMillis() - startedAt >= cfg.maxMinutes * 60_000L) {
                Toast.makeText(this@ClickerService, "انتهت المدة المحددة", Toast.LENGTH_SHORT).show()
                stopClicking(); return
            }

            val tv = points[idx % points.size]
            idx++
            val loc = IntArray(2)
            tv.getLocationOnScreen(loc)
            tap(loc[0] + tv.width / 2f, loc[1] + tv.height / 2f, cfg.holdMs)
            clicks++

            if (cfg.maxClicks > 0 && clicks >= cfg.maxClicks) {
                Toast.makeText(this@ClickerService, "تم الوصول لعدد النقرات المحدد", Toast.LENGTH_SHORT).show()
                stopClicking(); return
            }

            val jitter = (cfg.intervalMs * cfg.jitterPct / 100).toInt()
            val delta = if (jitter > 0) Random.nextInt(-jitter, jitter + 1) else 0
            handler.postDelayed(this, (cfg.intervalMs + delta).coerceAtLeast(20))
        }
    }

    private fun tap(x: Float, y: Float, hold: Long) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, hold.coerceAtLeast(1)))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
