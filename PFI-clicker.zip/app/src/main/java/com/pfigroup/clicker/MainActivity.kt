package com.pfigroup.clicker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private val gold = Color.parseColor("#D4AF37")
    private lateinit var status: TextView
    private lateinit var fInterval: EditText
    private lateinit var fJitter: EditText
    private lateinit var fHold: EditText
    private lateinit var fMax: EditText
    private lateinit var fMins: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        setPadding(0, dp(10), 0, dp(4))
    }

    private fun field(hint: String, value: String) = EditText(this).apply {
        setText(value)
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setTextColor(Color.BLACK)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply { setColor(gold); cornerRadius = dp(14).toFloat() }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(10) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = Prefs.load(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }

        root.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        })
        root.addView(label("P.F.I clicker", 26f, gold).apply { gravity = Gravity.CENTER })
        status = label("", 14f).apply { gravity = Gravity.CENTER }
        root.addView(status)

        root.addView(button("1) تفعيل خدمة إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2) إظهار اللوحة العائمة") {
            val s = ClickerService.instance
            if (s == null) {
                Toast.makeText(this, "فعّل الخدمة أولاً من الإعدادات", Toast.LENGTH_LONG).show()
            } else {
                s.showOverlay()
                moveTaskToBack(true)
            }
        })

        root.addView(label("الإعدادات", 18f, gold))
        root.addView(label("الفاصل بين النقرات (ميلي ثانية)"))
        fInterval = field("500", cfg.intervalMs.toString()); root.addView(fInterval)
        root.addView(label("عشوائية التوقيت % (0 = ثابت)"))
        fJitter = field("0", cfg.jitterPct.toString()); root.addView(fJitter)
        root.addView(label("مدة الضغطة (ميلي ثانية)"))
        fHold = field("20", cfg.holdMs.toString()); root.addView(fHold)
        root.addView(label("إيقاف بعد عدد نقرات (0 = بلا حد)"))
        fMax = field("0", cfg.maxClicks.toString()); root.addView(fMax)
        root.addView(label("إيقاف بعد مدة بالدقائق (0 = بلا حد)"))
        fMins = field("0", cfg.maxMinutes.toString()); root.addView(fMins)

        root.addView(button("حفظ الإعدادات") { save() })

        root.addView(label("الاستخدام: ضع الدوائر المرقّمة فوق أماكن النقر، ثم اضغط ▶ . + و − لإضافة وحذف النقاط، والنقر يتم بالترتيب.", 13f, Color.LTGRAY))
        root.addView(label("Produced by Berratone • P.F.I Group", 12f, gold).apply { gravity = Gravity.CENTER })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0E1319"))
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        val enabled = ClickerService.instance != null
        status.text = if (enabled) "✅ الخدمة مفعّلة" else "⚠️ الخدمة غير مفعّلة"
    }

    private fun save() {
        fun n(e: EditText, d: Long) = e.text.toString().toLongOrNull() ?: d
        val cfg = Cfg(
            n(fInterval, 500).coerceAtLeast(20),
            n(fJitter, 0).toInt().coerceIn(0, 90),
            n(fHold, 20).coerceAtLeast(1),
            n(fMax, 0).toInt().coerceAtLeast(0),
            n(fMins, 0).toInt().coerceAtLeast(0)
        )
        Prefs.save(this, cfg)
        Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
    }
}
