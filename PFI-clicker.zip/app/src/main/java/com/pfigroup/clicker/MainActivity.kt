package com.pfigroup.clicker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private val gold = Color.parseColor("#D4AF37")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showPanelIfReady(): Boolean {
        val s = ClickerService.instance ?: return false
        s.showOverlay()
        finish()
        return true
    }

    private fun smallBtn(label: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        minWidth = 0
        minHeight = 0
        setPadding(dp(6), dp(8), dp(6), dp(8))
        setTextColor(if (filled) Color.BLACK else gold)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            if (filled) setColor(gold) else { setColor(Color.TRANSPARENT); setStroke(dp(1), gold) }
        }
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            .apply { marginStart = dp(3); marginEnd = dp(3) }
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (showPanelIfReady()) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64)).apply { marginEnd = dp(12) }
        })

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        col.addView(TextView(this).apply {
            text = "P.F.I clicker"
            textSize = 18f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "فعّل الخدمة مرة واحدة من إعدادات إمكانية الوصول، وبعدها تظهر اللوحة الصغيرة تلقائياً."
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, dp(4), 0, dp(10))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(smallBtn("تفعيل الخدمة", true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        row.addView(smallBtn("▶ الشرح", false) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Links.VIDEO)))
        })
        row.addView(smallBtn("ℹ عنا", false) {
            startActivity(Intent(this, AboutActivity::class.java))
        })
        col.addView(row)
        root.addView(col)

        setContentView(root)
        window.setLayout(
            minOf((resources.displayMetrics.widthPixels * 0.94).toInt(), dp(480)),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    override fun onResume() {
        super.onResume()
        showPanelIfReady()
    }
}
