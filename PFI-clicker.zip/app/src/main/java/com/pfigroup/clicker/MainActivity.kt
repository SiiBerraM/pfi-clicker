package com.pfigroup.clicker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private val gold = Color.parseColor("#D4AF37")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showPanelIfReady(): Boolean {
        val s = ClickerService.instance ?: return false
        s.showOverlay()
        finish()
        return true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (showPanelIfReady()) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
        })
        root.addView(TextView(this).apply {
            text = "P.F.I clicker"
            textSize = 20f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "فعّل الخدمة مرة واحدة من إعدادات إمكانية الوصول، وبعدها تظهر اللوحة الصغيرة تلقائياً فوق الشاشة."
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(12))
        })
        root.addView(Button(this).apply {
            text = "تفعيل الخدمة"
            setTextColor(Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { setColor(gold); cornerRadius = dp(14).toFloat() }
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        fun outline(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setTextColor(gold)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), gold)
            }
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        root.addView(outline("▶ شرح حل مشكلة التفعيل") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Links.VIDEO)))
        })
        root.addView(outline("ℹ عنا") {
            startActivity(Intent(this, AboutActivity::class.java))
        })
        root.addView(TextView(this).apply {
            text = "Produced by Berratone • P.F.I Group"
            textSize = 11f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        showPanelIfReady()
    }
}
