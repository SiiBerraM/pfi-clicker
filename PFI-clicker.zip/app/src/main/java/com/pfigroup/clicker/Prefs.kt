package com.pfigroup.clicker

import android.content.Context

data class Cfg(
    val intervalMs: Long,   // الفاصل بين نقرتين
    val jitterPct: Int,     // عشوائية الوقت %
    val holdMs: Long,       // مدة الضغطة
    val maxClicks: Int,     // 0 = بلا حد
    val maxMinutes: Int     // 0 = بلا حد
)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("pfi_clicker", Context.MODE_PRIVATE)

    fun load(c: Context): Cfg = sp(c).let {
        Cfg(
            it.getLong("interval", 500),
            it.getInt("jitter", 0),
            it.getLong("hold", 20),
            it.getInt("max", 0),
            it.getInt("mins", 0)
        )
    }

    fun save(c: Context, cfg: Cfg) {
        sp(c).edit()
            .putLong("interval", cfg.intervalMs)
            .putInt("jitter", cfg.jitterPct)
            .putLong("hold", cfg.holdMs)
            .putInt("max", cfg.maxClicks)
            .putInt("mins", cfg.maxMinutes)
            .apply()
    }
}
