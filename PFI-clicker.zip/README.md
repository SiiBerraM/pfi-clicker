# P.F.I clicker
Auto clicker for Android (Accessibility Service). Icon: Berratone.

Build: push to GitHub -> Actions -> "Build APK" -> download artifact `PFI-clicker-apk`.
Or open in Android Studio and run assembleDebug.
